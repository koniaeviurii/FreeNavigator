# Free Navigator — developer preview 0.1.0

Android project skeleton for an independent navigation application. Target use: Russia; UI language: Russian. The project is not a finished navigator and this archive is not an APK.

## Included
- Android application shell and manifest permissions.
- MapLibre Android dependency declared for the future map screen.
- Normalized search models and online/offline search orchestration interfaces.
- Route models and online/offline route orchestration with fallback on empty online results and coroutine cancellation preserved.

## Not implemented yet
- A configured MapLibre style and production tile source.
- Concrete online geocoder and local/offline address + POI index.
- Valhalla (or another routing engine) client and downloadable regional road graphs.
- Traffic provider. OpenStreetMap data alone does not provide live traffic.
- Offline map package manager, voice guidance, radar/camera dataset, background navigation service, and final UI/theme controls.
- Automated tests, signing configuration, and device validation.

## Build
Open this folder in Android Studio (JDK 17; Android SDK platform 35), allow Gradle to download dependencies, then run `:app:assembleDebug`.

This environment did not contain Android SDK, Gradle, or adb, so an APK could not be compiled or tested here. Do not install this source archive as an application. A debug APK must be produced and tested on a real device before it can be called ready.

## Data and service notes
Production deployment needs suitable licensed/operational providers for tiles, geocoding, routing and live traffic. Public demo endpoints are not a reliable production backend. Offline mode requires locally stored regional map tiles, road graph, and search index; merely caching map images is insufficient.
