package ru.freenavigator

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding

/** Initial app shell. Map and routing providers are deliberately not represented as ready. */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "FREE NAVIGATOR"
            textSize = 25f
            gravity = Gravity.CENTER
            setPadding(12)
        }
        val status = TextView(this).apply {
            text = "Тестовая оболочка проекта\n\nСледующий этап — подключение картографического стиля, поиска и маршрутизатора."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(12)
        }
        val themeButton = Button(this).apply { text = "Переключение темы — будет подключено"; isEnabled = false }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(themeButton, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }
}
